
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;
import java.util.concurrent.Semaphore;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Ile pszczol wybierasz? ");
        int n;
        try {
            n = Integer.parseInt(sc.nextLine().trim());
            if (n <= 0) {
                System.out.println("Liczba pszczol ma byc wieksza od 0.");
                return;
            }
        } catch (NumberFormatException e) {
            System.out.println("Napewno podałeś odpowiednią liczbę?. Sprobuj ponownie.");
            return;
        }

        // Dwa przeloty, kazdy z 1 miejscem synchronizowanym przez semafor
        Semaphore przelot1 = new Semaphore(1);
        Semaphore przelot2 = new Semaphore(1);

        List<Bee> bees = new ArrayList<>();
        for (int i = 1; i <= n; i++) {
            Bee b = new Bee(i, przelot1, przelot2);
            bees.add(b);
            b.start();
        }

        // Dodajemy hook, aby przy zamknieciu (Ctrl+C) zapisac przeprowadzone operacje do pliku
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("\nZapisuje podsumowanie do pliku symulacja_ulu.txt");
            try (PrintWriter out = new PrintWriter(new FileWriter("symulacja_ulu.txt"))) {
                out.println("id | wejścia | wyjścia | sr_czekanie_wejscie_ms(zaokr) | sr_czekanie_wyjscie_ms(zaokr) | sr_czekanie_ogolne_ms(2 miejsca po przeciku)");
                // Uzywamy Locale.US aby wymusic kropke jako separator dziesietny
                for (Bee b : bees) {
                    out.printf(Locale.US, "%d | %d | %d | %.0f | %.0f |%.2f%n",
                            b.getBeeId(),
                            b.getEntries(),
                            b.getExits(),
                            b.getsrednie_wejscie(),    // bez miejsc po przecinku
                            b.getsrednie_wyjscie(),    // bez miejsc po przecinku
                            b.getsrednie_czekanie());  // ogolna srednia z 2 miejscami
                }
                System.out.println("Zapis zakończony.");
            } catch (IOException e) {
                System.err.println("Nie udało się zapisać: " + e.getMessage());
            }
            // Przerwij watki pszczol
            for (Bee b : bees) b.interrupt();
            try { Thread.sleep(300); } catch (InterruptedException ignored) {}
        }));

        // Program glowny czeka az uzytkownik wpisze 'wyjscie' lub przerwie program
        System.out.println("Symulacja uruchomiona. W celu zakończenia i podsumowania przeprowadzonych operacji, wpisz 'wyjscie' .");
        while (true) {
            String line = sc.nextLine();
            if (line == null) break;
            if ("wyjscie".equalsIgnoreCase(line.trim())) {
                System.exit(0); // spowoduje uruchomienie shutdown hook
            }
        }
    }
}
