
import java.util.Random;
import java.util.concurrent.Semaphore;

public class Bee extends Thread {
    private final int id;
    private final Semaphore sem1;
    private final Semaphore sem2;
    private final Random rnd = new Random();

    // statystyki
    private int wejscia = 0;
    private int wyjscia = 0;
    private long Laczne_czekanie_mls = 0;
    // rozbite sumy na osobne dla wejsc i wyjsc
    private long Laczne_czekanie_wejscie_mls = 0;
    private long Laczne_czekanie_wyjscie_mls = 0;

    public Bee(int id, Semaphore sem1, Semaphore sem2) {
        this.id = id;
        this.sem1 = sem1;
        this.sem2 = sem2;
        setName("Bee nr" + id);
    }

    // getter zwracajacy wewnetrzne id pszczoly
    public int getBeeId() {
        return id;
    }

    // Metody synchronizowane, chronia dostep do pol statystycznych
    public synchronized double getsrednie_czekanie() {
        int attempts = wejscia + wyjscia;
        return attempts == 0 ? 0.0 : (double) Laczne_czekanie_mls / attempts;
    }

    public synchronized double getsrednie_wejscie() {
        return wejscia == 0 ? 0.0 : (double) Laczne_czekanie_wejscie_mls / wejscia;
    }

    public synchronized double getsrednie_wyjscie() {
        return wyjscia == 0 ? 0.0 : (double) Laczne_czekanie_wyjscie_mls / wyjscia;
    }

    public synchronized int getEntries() { return wejscia; }
    public synchronized int getExits() { return wyjscia; }

    // Zwiekszanie licznikow i sumy oczekiwan w synchronizowany sposob
    private synchronized void recordWaitAndEntry(long czekanie_mls) {
        Laczne_czekanie_wejscie_mls += czekanie_mls;
        Laczne_czekanie_mls += czekanie_mls; // zachowujemy tez ogolna sume
        wejscia++;
    }

    private synchronized void recordWaitAndExit(long czekanie_mls) {
        Laczne_czekanie_wyjscie_mls += czekanie_mls;
        Laczne_czekanie_mls += czekanie_mls; // zachowujemy tez ogolna sume
        wyjscia++;
    }

    // Proba przejscia przez dowolny otwór (wejscie lub wyjscie).
    private void przejscie(String action) throws InterruptedException {
        long waitStart = System.currentTimeMillis();

        while (true) {
            // Szybka proba na przelot 1
            if (sem1.tryAcquire()) {
                long waited = System.currentTimeMillis() - waitStart;
                System.out.println("Pszczoła o nr " + id + " " + action + " przez otwór 1 (oczekiwanie do tej pory " + waited + " ms)");
                // przejscie zajmuje 1s, czyli 1000ms
                Thread.sleep(1000);
                sem1.release();
                if ("wlatuje".equals(action)) recordWaitAndEntry(waited);
                else recordWaitAndExit(waited);
                return;
            } else {
                // jesli 1 zajety, sprawdzamy drugi (zajmuje to 300ms)
                System.out.println("Pszczoła o nr " + id + " otwór 1 jest zajety, sprawdza otwór 2");
                Thread.sleep(300);
                if (sem2.tryAcquire()) {
                    long waited = System.currentTimeMillis() - waitStart;
                    System.out.println("Pszczoła o nr " + id + " " + action + " przez otwór 2 (oczekiwanie do tej pory " + waited + " ms)");
                    Thread.sleep(1000);
                    sem2.release();
                    if ("wlatuje".equals(action)) recordWaitAndEntry(waited);
                    else recordWaitAndExit(waited);
                    return;
                } else {
                    // jesli oba otwory zajete, czekamy i ponawiamy próbę
                    System.out.println("Pszczoła o nr " + id + " oba otwory sa zajete, musi czekac");
                    Thread.sleep(200);
                }
            }
        }
    }

    @Override
    public void run() {
        try {
            while (!isInterrupted()) {
                // Na zewnatrz: 5-10s
                int outside = 5000 + rnd.nextInt(5001);
                System.out.println("Pszczoła o nr " + id + " znajduje się na zewnątrz, odpoczywa " + outside + " ms");
                Thread.sleep(outside);

                // Wejscie do ulu
                System.out.println("Pszczoła o nr " + id + " zbliża się do ulu i próbuję do niego wlecieć");
                przejscie("wlatuje");

                // W ulu: 1-5s
                int inside = 1000 + rnd.nextInt(4001);
                System.out.println("Pszczoła o nr " + id + " znajduje się w ulu, przebywa w nim  " + inside + " ms");
                Thread.sleep(inside);

                // Wyjscie z ulu
                System.out.println("Pszczoła o nr " + id + " probuje opuścić ul");
                przejscie("wylatuje");
            }
        } catch (InterruptedException e) {
            // Watek zostal przerwany - konczymy cicho
        }
        System.out.println("Pszczoła o nr " + id + " przestaje już latać, bo się zmęczyła.");
    }
}
