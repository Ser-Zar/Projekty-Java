// Klasa reprezentujaca numer PESEL
class PESEL {
    // Przechowuje numer PESEL jako tekst (String)
    private String numer;

    // Konstruktor przyjmujacy numer PESEL jako parametr
    public PESEL(String numer) {
        this.numer = numer;
    }

    // Metoda sprawdzajaca poprawnosc numeru PESEL
    public boolean check() {
        // Sprawdzamy, czy PESEL sklada sie z dokladnie 11 cyfr
        if (!numer.matches("\\d{11}")) return false;

        // Wagi do obliczenia cyfry kontrolnej (standardowy algorytm PESEL)
        int[] wagi = {1, 3, 7, 9, 1, 3, 7, 9, 1, 3};
        int suma = 0;

        // Liczymy sume iloczynow kazdej cyfry przez jej wage
        for (int i = 0; i < 10; i++) {
            int cyfra = Character.getNumericValue(numer.charAt(i)); // pobieramy kolejna cyfre
            suma += wagi[i] * cyfra; // dodajemy iloczyn do sumy
        }

        // Wyliczamy cyfre kontrolna zgodnie z algorytmem
        int kontrolna = (10 - (suma % 10)) % 10;

        // Pobieramy ostatnia cyfre (rzeczywista cyfra kontrolna z numeru)
        int ostatnia = Character.getNumericValue(numer.charAt(10));

        // Porownujemy obliczona i rzeczywista cyfre kontrolna
        return kontrolna == ostatnia;
    }

    // Metoda porownujaca dwa obiekty klasy PESEL
    // Zwraca true jesli numery sa identyczne
    public boolean compare(PESEL inny) {
        return this.numer.equals(inny.numer);
    }
}


