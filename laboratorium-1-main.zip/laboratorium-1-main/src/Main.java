
// Klasa glowna programu
public class Main {
    public static void main(String[] args) {
        // Jesli nie podano zadnych argumentow w linii polecen
        if (args.length == 0) {
            System.out.println("Brak parametrow");
            return;
        }

        // JESLI PODANO TYLKO JEDEN PESEL
        if (args.length == 1) {
            // Tworzymy obiekt klasy PESEL z pierwszego argumentu
            PESEL p = new PESEL(args[0]);
            // Jesli PESEL poprawny -> kod wyjscia 1
            // Jesli niepoprawny -> kod wyjscia 0
            System.exit(p.check() ? 1 : 0);
        }

        // JESLI PODANO DWA PESELE
        if (args.length == 2) {
            // Tworzymy dwa obiekty klasy PESEL
            PESEL p1 = new PESEL(args[0]);
            PESEL p2 = new PESEL(args[1]);

            // Jesli ktorykolwiek z PESELi jest niepoprawny -> wynik 0
            if (!p1.check() || !p2.check()) {
                System.out.println("Wynik porownania: 0");
                System.exit(0);
            }

            // Jesli oba PESELe sa poprawne -> porownujemy je
            // Jesli identyczne -> wynik 1, jesli rozne -> wynik 0
            int wynik = p1.compare(p2) ? 1 : 0;
            System.out.println("Wynik porownania: " + wynik);
            System.exit(wynik);

        }


        // Jesli podano wiecej niz dwa argumenty -> komunikat bledu
        System.out.println("Zbyt wiele parametrow");
    }
}

