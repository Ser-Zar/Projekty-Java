Dear Student,

You've received 4.0 out of 5.0 points.

"issues": 
    "[1p] Program has not compared all of the pesels correctly.
