package pl.edu.uj.javaframe; // Deklarujemy pakiet, w którym znajduje się interfejs

public interface Applayable // Interfejs reprezentujący operację, którą można zastosować do obiektu Series
{
    void apply(Series v); // Metoda, która przyjmuje serię danych i wykonuje na niej określoną operację
}
