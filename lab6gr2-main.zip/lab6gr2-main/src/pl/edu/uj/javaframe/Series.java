package pl.edu.uj.javaframe; // Deklarujemy pakiet, w którym znajduje się klasa Series

import java.lang.reflect.InvocationTargetException; // Importujemy klasy potrzebne do refleksji
import java.util.ArrayList; // Importujemy ArrayList do przechowywania wartości w serii

public class Series // Klasa reprezentująca pojedynczą kolumnę danych
{
    ArrayList<Value> values = new ArrayList<>(); // Lista przechowująca wartości w serii
    String name; // Nazwa serii (kolumny)
    Class<? extends Value> type; // Typ wartości przechowywanych w serii

    public Series(Class type, String name) // Konstruktor przyjmujący typ wartości i nazwę serii
    {
        this.name = name; // Zapisujemy nazwę serii w polu name
        this.type = type; // Zapisujemy typ wartości w polu type
    }

    public void addValue(String value) // Metoda dodająca nową wartość tekstową do serii
    {
        try // Blok try do obsługi wyjątków związanych z refleksją
        {
            values.add(type.getDeclaredConstructor().newInstance().create(value)); // Tworzymy nowy obiekt typu Value na podstawie tekstu i dodajemy go do listy
        }
        catch (InstantiationException e) // Łapiemy wyjątek tworzenia instancji klasy
        {
            e.printStackTrace(); // Wypisujemy stos wywołań wyjątku
        }
        catch (IllegalAccessException e) // Łapiemy wyjątek braku dostępu do konstruktora
        {
            e.printStackTrace(); // Wypisujemy stos wywołań wyjątku
        }
        catch (InvocationTargetException e) // Łapiemy wyjątek z konstruktora wywołanego przez refleksję
        {
            e.printStackTrace(); // Wypisujemy stos wywołań wyjątku
        }
        catch (NoSuchMethodException e) // Łapiemy wyjątek braku odpowiedniego konstruktora
        {
            e.printStackTrace(); // Wypisujemy stos wywołań wyjątku
        }
    }

    public Series iloc(int from, int to) // Metoda tworząca podserię z zakresu indeksów [from, to)
    {
        Series result = new Series(type, name); // Tworzymy nową serię z tym samym typem i nazwą
        for (int i = from; i < to && i < this.values.size(); i++) // Iterujemy po wartościach w zadanym zakresie, pilnując końca listy
        {
            result.addValue(this.values.get(i).toString()); // Dodajemy do wynikowej serii wartości przekonwertowane z powrotem na tekst
        }
        return result; // Zwracamy utworzoną podserię
    }

    public int size() // Metoda zwracająca liczbę elementów w serii
    {
        return values.size(); // Zwracamy rozmiar listy wartości
    }

    public String getAsString(int index) // Metoda zwracająca wartość z serii pod zadanym indeksem jako tekst
    {
        return values.get(index).toString(); // Zwracamy wynik wywołania toString na odpowiedniej wartości
    }
}
