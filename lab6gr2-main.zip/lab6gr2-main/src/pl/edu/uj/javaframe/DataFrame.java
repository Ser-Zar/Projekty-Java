package pl.edu.uj.javaframe; // Deklarujemy pakiet, w którym znajduje się klasa DataFrame

import java.io.*; // Importujemy klasy wejścia/wyjścia
import java.util.ArrayList; // Importujemy ArrayList do przechowywania kolumn

public class DataFrame // Klasa reprezentująca prostą ramkę danych podobną do DataFrame z Pythona
{
    ArrayList<Series> columns = new ArrayList<>(); // Lista kolumn przechowywanych jako obiekty typu Series

    public DataFrame(Class<? extends Value>[] types, String[] vals) // Konstruktor tworzący ramkę danych na podstawie typów i nazw kolumn
    {
        for (int i = 0; i < types.length; i++) // Iterujemy po wszystkich typach kolumn
        {
            columns.add(new Series(types[i], vals[i])); // Dodajemy nową kolumnę (Series) do listy kolumn
        }
    }

    public void addRow(String[] values) // Metoda dodająca nowy wiersz wartości do wszystkich kolumn
    {
        for (int i = 0; i < columns.size(); i++) // Iterujemy po wszystkich kolumnach
        {
            columns.get(i).addValue(values[i]); // Dodajemy odpowiednią wartość tekstową do danej kolumny
        }
    }

    public void head() // Metoda wypisująca pierwsze wiersze ramki danych
    {
        int rows = 0; // Zmienna zliczająca wypisane wiersze
        for (int j = 0; j < columns.size(); j++) // Iterujemy po wszystkich kolumnach, aby wypisać nagłówki
        {
            System.out.print(columns.get(j).name + " "); // Wypisujemy nazwę kolumny oraz spację
        }
        System.out.println(); // Kończymy linię po wypisaniu nagłówków

        for (int j = 0; j < columns.get(0).values.size(); j++) // Iterujemy po wierszach danych, używając liczby wierszy pierwszej kolumny
        {
            for (int i = 0; i < columns.size(); i++) // Iterujemy po każdej kolumnie w danym wierszu
            {
                columns.get(i).values.get(j).print(); // Wypisujemy wartość z danej kolumny i wiersza
                System.out.print(' '); // Dodajemy spację między wartościami
            }
            System.out.println(); // Kończymy linię po wypisaniu całego wiersza
            rows++; // Zwiększamy licznik wypisanych wierszy
            if (rows > 5) // Jeśli wypisaliśmy więcej niż pięć wierszy
            {
                return; // Kończymy działanie metody head
            }
        }
    }

    public DataFrame iloc(int from, int to) // Metoda zwracająca podramkę z zakresu wierszy [from, to)
    {
        @SuppressWarnings("unchecked")
        Class<? extends Value>[] types = new Class[columns.size()]; // Tworzymy tablicę typów dla nowej ramki
        String[] names = new String[columns.size()]; // Tworzymy tablicę nazw kolumn dla nowej ramki
        for (int i = 0; i < columns.size(); i++) // Iterujemy po wszystkich kolumnach
        {
            types[i] = columns.get(i).type; // Przepisujemy typ kolumny do tablicy typów
            names[i] = columns.get(i).name; // Przepisujemy nazwę kolumny do tablicy nazw
        }

        DataFrame result = new DataFrame(types, names); // Tworzymy nową ramkę danych z tymi samymi nazwami i typami kolumn

        for (int i = from; i < to; i++) // Iterujemy po wierszach od from do to-1
        {
            String[] vals = new String[columns.size()]; // Tworzymy tablicę wartości tekstowych dla danego wiersza
            for (int ci = 0; ci < columns.size(); ci++) // Iterujemy po wszystkich kolumnach
            {
                vals[ci] = columns.get(ci).values.get(i).toString(); // Pobieramy wartość jako tekst z odpowiedniej kolumny i wiersza
            }
            result.addRow(vals); // Dodajemy nowy wiersz do wynikowej ramki
        }
        return result; // Zwracamy nową ramkę danych
    }

    public static DataFrame readCSV(String path, Class<? extends Value>[] types) throws IOException // Metoda statyczna wczytująca ramkę z pliku CSV
    {
        FileInputStream fstream = new FileInputStream(path); // Tworzymy strumień bajtów z pliku
        BufferedReader br = new BufferedReader(new InputStreamReader(fstream)); // Owijamy strumień w BufferedReader

        String strLine; // Zmienna przechowująca aktualnie wczytaną linię

        DataFrame df = null; // Zmienna na obiekt DataFrame, który utworzymy po wczytaniu nagłówków
        while ((strLine = br.readLine()) != null) // Czytamy linie pliku aż do końca
        {
            String[] row = strLine.split(","); // Dzielimy linię po przecinkach, tworząc tablicę wartości
            if (df == null) // Jeśli to pierwsza wczytana linia
            {
                df = new DataFrame(types, row); // Tworzymy ramkę danych, traktując ją jako nagłówki kolumn
            }
            else
            {
                df.addRow(row); // Kolejne linie dodajemy jako nowe wiersze danych
            }
        }

        br.close(); // Zamykamy BufferedReader po zakończeniu odczytu

        return df; // Zwracamy wczytaną ramkę danych
    }

    public void apply(Applayable a, String name) // Metoda wykonująca operację apply na wskazanej kolumnie w jednym wątku
    {
        Series s = null; // Zmienna na znalezioną serię o zadanej nazwie
        for (int i = 0; i < columns.size(); i++) // Iterujemy po wszystkich kolumnach
        {
            if (columns.get(i).name.equals(name)) // Sprawdzamy, czy nazwa kolumny zgadza się z podaną
            {
                s = columns.get(i); // Przypisujemy znalezioną kolumnę do zmiennej s
                break; // Przerywamy pętlę po znalezieniu kolumny
            }
        }
        a.apply(s); // Wywołujemy operację apply na znalezionej serii
    }

    /************************TODO***********************************/

    public Series apply(Applayable a, String name, int njobs) // Metoda wykonująca operację apply równolegle w njobs wątkach na kolumnie o podanej nazwie
    {
        Series oryginalna = null; // Zmienna na serię odpowiadającą podanej nazwie kolumny
        for (int i = 0; i < columns.size(); i++) // Iterujemy po wszystkich kolumnach
        {
            if (columns.get(i).name.equals(name)) // Sprawdzamy, czy nazwa kolumny jest zgodna z parametrem name
            {
                oryginalna = columns.get(i); // Zapisujemy referencję do znalezionej serii
                break; // Przerywamy pętlę po znalezieniu kolumny
            }
        }

        if (oryginalna == null) // Jeśli nie znaleziono kolumny o takiej nazwie
        {
            return null; // Zwracamy null, ponieważ nie możemy nic przetworzyć
        }

        int rozmiar = oryginalna.values.size(); // Pobieramy liczbę elementów w znalezionej serii

        if (rozmiar == 0 || njobs <= 0) // Jeśli seria jest pusta albo liczba wątków jest niepoprawna
        {
            return oryginalna; // Zwracamy oryginalną serię bez zmian
        }

        int rozmiarKawałka = (int) Math.ceil(rozmiar / (double) njobs); // Obliczamy rozmiar pojedynczego kawałka serii dla wątku

        ArrayList<ApplayableThread> watki = new ArrayList<>(); // Tworzymy listę wątków, które będą przetwarzać części serii

        for (int start = 0; start < rozmiar; start += rozmiarKawałka) // Iterujemy po serii skokami o rozmiarKawałka
        {
            int end = Math.min(start + rozmiarKawałka, rozmiar); // Obliczamy koniec aktualnego kawałka, pilnując górnej granicy
            Series podseria = oryginalna.iloc(start, end); // Tworzymy podserię z zakresu [start, end)

            ApplayableThread watek = new ApplayableThread(podseria, a); // Tworzymy wątek, który przetworzy tę podserię
            watki.add(watek); // Dodajemy wątek do listy wątków
            watek.start(); // Uruchamiamy wątek, aby zaczął wykonywać operację apply na podserii
        }

        for (ApplayableThread watek : watki) // Iterujemy po wszystkich wątkach
        {
            try // Blok try do obsługi możliwego przerwania wątku
            {
                watek.join(); // Czekamy, aż dany wątek zakończy swoje działanie
            }
            catch (InterruptedException e) // Łapiemy wyjątek przerwania wątku
            {
                e.printStackTrace(); // Wypisujemy stos wywołań, aby ułatwić diagnostykę
            }
        }

        Series wynik = new Series(oryginalna.type, oryginalna.name); // Tworzymy nową serię, w której zbierzemy wyniki z wszystkich kawałków

        for (ApplayableThread watek : watki) // Iterujemy ponownie po wszystkich wątkach w kolejności ich tworzenia
        {
            for (Value v : watek.result.values) // Iterujemy po wszystkich wartościach w przetworzonej podserii tego wątku
            {
                wynik.values.add(v); // Dodajemy wartość do wynikowej serii, zachowując kolejność wierszy
            }
        }

        return wynik; // Zwracamy serię zawierającą przetworzone wartości dla całej kolumny
    }

    class ApplayableThread extends Thread // Wewnętrzna klasa reprezentująca wątek wykonujący operację apply na fragmencie serii
    {
        Series result; // Pole przechowujące wynik przetworzenia podserii
        private final Series seria; // Prywatne pole przechowujące referencję do podserii, którą wątek ma przetworzyć
        private final Applayable zadanie; // Prywatne pole przechowujące zadanie typu Applayable do wykonania

        public ApplayableThread(Series s, Applayable task) // Konstruktor wątku przyjmujący podserię i zadanie do wykonania
        {
            this.seria = s; // Zapisujemy przekazaną podserię w polu instancji
            this.zadanie = task; // Zapisujemy przekazane zadanie w polu instancji
        }

        @Override
        public void run() // Metoda wykonywana po uruchomieniu wątku
        {
            zadanie.apply(seria); // Wywołujemy operację apply na przekazanej podserii
            result = seria; // Po przetworzeniu zapisujemy referencję do wyniku w polu result
        }
    }

    /**************************TODO*********************************/
}
