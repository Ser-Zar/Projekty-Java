package pl.edu.uj.javaframe; // Deklarujemy pakiet, w którym znajduje się klasa Factorize

import java.util.ArrayList; // Importujemy ArrayList do przechowywania nowych wartości w serii

public class Factorize implements Applayable // Klasa Factorize implementuje interfejs Applayable
{
    @Override
    public void apply(Series v) // Metoda wykonująca operację na podanej serii v
    {
        ArrayList<Value> noweWartosci = new ArrayList<>(); // Tworzymy listę, w której zapiszemy przetworzone wartości serii

        for (Value wartosc : v.values) // Iterujemy po wszystkich wartościach w przekazanej serii
        {
            int liczba = Integer.parseInt(wartosc.toString()); // Konwertujemy wartość z typu Value do liczby całkowitej

            int sumaCzynnikow = sumaCzynnikowPierwszych(liczba); // Obliczamy sumę czynników pierwszych tej liczby

            Value nowa = new Int().create(Integer.toString(sumaCzynnikow)); // Tworzymy nowy obiekt typu Int z wartością sumy czynników

            noweWartosci.add(nowa); // Dodajemy nową wartość do listy wynikowej
        }

        v.values = noweWartosci; // Podmieniamy listę wartości w serii na nową listę z przetworzonymi wynikami
    }

    private int sumaCzynnikowPierwszych(int n) // Prywatna metoda obliczająca sumę czynników pierwszych liczby n
    {
        int liczba = n; // Kopiujemy wejściową liczbę do zmiennej roboczej
        int suma = 0; // Zmienna przechowująca sumę czynników pierwszych

        for (int dzielnik = 2; dzielnik * dzielnik <= liczba; dzielnik++) // Iterujemy po potencjalnych dzielnikach od 2 do pierwiastka z liczby
        {
            while (liczba % dzielnik == 0) // Dopóki aktualny dzielnik dzieli liczbę bez reszty
            {
                suma += dzielnik; // Dodajemy dzielnik do sumy czynników
                liczba /= dzielnik; // Dzielimy liczbę przez dzielnik, redukując ją
            }
        }

        if (liczba > 1) // Jeśli po pętli pozostał czynnik większy od 1, to jest on ostatnim czynnikiem pierwszym
        {
            suma += liczba; // Dodajemy ten ostatni czynnik do sumy
        }

        return suma; // Zwracamy obliczoną sumę czynników pierwszych
    }
}
