import pl.edu.uj.javaframe.*; // Importujemy wszystkie klasy z pakietu pl.edu.uj.javaframe

import java.io.BufferedReader; // Importujemy BufferedReader do wczytywania tekstu z pliku
import java.io.FileReader; // Importujemy FileReader do otwierania pliku
import java.io.IOException; // Importujemy IOException do obsługi błędów wejścia/wyjścia

public class Main // Główna klasa programu uruchamianego z linii komend
{
    public static void main(String[] args) // Metoda startowa programu wywoływana przez JVM
    {
        if (args.length != 4) // Sprawdzamy, czy użytkownik podał dokładnie cztery argumenty
        {
            System.out.println("Użycie: java Main plik.csv nazwaKolumny njobs indeks"); // Wypisujemy instrukcję poprawnego użycia programu
            return; // Kończymy działanie programu, bo nie ma danych do przetworzenia
        }

        String sciezkaPliku = args[0]; // Pierwszy argument to ścieżka do pliku CSV z danymi
        String nazwaKolumny = args[1]; // Drugi argument to nazwa kolumny z liczbami typu int do przetworzenia
        int njobs = Integer.parseInt(args[2]); // Trzeci argument to liczba wątków, w których ma być wykonana operacja apply
        int indeksWyniku = Integer.parseInt(args[3]); // Czwarty argument to indeks w wynikowej serii, który ma zostać wypisany

        try // Blok try do obsługi możliwych wyjątków wejścia/wyjścia
        {
            BufferedReader reader = new BufferedReader(new FileReader(sciezkaPliku)); // Tworzymy BufferedReader do odczytu pliku CSV
            String liniaNaglowka = reader.readLine(); // Wczytujemy pierwszą linię pliku, która zawiera nazwy kolumn
            reader.close(); // Zamykamy czytnik pliku, ponieważ DataFrame otworzy plik ponownie samodzielnie

            if (liniaNaglowka == null) // Sprawdzamy, czy plik nie był pusty
            {
                System.out.println("Pusty plik wejściowy."); // Informujemy użytkownika o pustym pliku
                return; // Kończymy działanie programu, bo nie ma danych do przetworzenia
            }

            String[] naglowki = liniaNaglowka.split(","); // Dzielimy linię nagłówka po przecinkach, aby uzyskać nazwy kolumn

            Class[] typy = new Class[naglowki.length]; // Tworzymy tablicę typów dla wszystkich kolumn bez użycia klasy Value

            for (int i = 0; i < naglowki.length; i++) // Iterujemy po wszystkich nazwach kolumn
            {
                if (naglowki[i].equals(nazwaKolumny)) // Sprawdzamy, czy aktualna kolumna to ta, którą chcemy przetwarzać
                {
                    typy[i] = Int.class; // Dla wskazanej kolumny ustawiamy typ Int, ponieważ mają tam być liczby całkowite
                }
                else
                {
                    typy[i] = MyString.class; // Dla pozostałych kolumn ustawiamy typ MyString, aby przechowywać tekst
                }
            }

            DataFrame df = DataFrame.readCSV(sciezkaPliku, typy); // Wczytujemy plik CSV do obiektu DataFrame, przekazując tablicę typów jako typ surowy

            Applayable faktorizer = new Factorize(); // Tworzymy obiekt klasy Factorize, która implementuje interfejs Applayable

            Series wynikowaSeria = df.apply(faktorizer, nazwaKolumny, njobs); // Wywołujemy równoległe przetwarzanie wskazanej kolumny w njobs wątkach

            if (wynikowaSeria == null) // Sprawdzamy, czy metoda apply zwróciła niepusty wynik
            {
                System.out.println("Nie znaleziono kolumny o nazwie: " + nazwaKolumny); // Informujemy o braku kolumny o podanej nazwie
                return; // Kończymy działanie programu, bo nie mamy wyników do wypisania
            }

            if (indeksWyniku < 0 || indeksWyniku >= wynikowaSeria.size()) // Sprawdzamy, czy indeks mieści się w zakresie serii
            {
                System.out.println("Niepoprawny indeks wyniku."); // Informujemy użytkownika o błędnym indeksie
                return; // Kończymy działanie programu, bo nie możemy wypisać nieistniejącego elementu
            }

            System.out.println(wynikowaSeria.getAsString(indeksWyniku)); // Wypisujemy na standardowe wyjście wartość z wynikowej serii pod zadanym indeksem jako tekst
        }
        catch (IOException e) // Łapiemy wyjątek związany z błędami wejścia/wyjścia
        {
            e.printStackTrace(); // Wypisujemy stos wywołań, aby ułatwić diagnostykę błędu
        }
    }
}
