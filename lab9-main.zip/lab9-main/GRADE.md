Dear Student,

I regret to inform you that you've received only **1.0** out of 5 points for this assignment.
<details><summary>You have already managed to pass 1 tests, so that is encouraging!</summary>&emsp;☑&nbsp;[1p]&nbsp;Testing&nbsp;EchoServer</details>

There still exist some issues that should be addressed before the deadline: **2026-01-28 20:00:00 CET (+0100)**. For further details, please refer to the following list:

<details><summary>[[4p] Testing Client failed Your server/client code returned nothing, or returned number was not integer. Got for port: 36891 and for result: None. Expected -660 for input: 44*-15</summary></details>

-----------
I remain your faithful servant\
_Bobot_\
_January 14, AD 2026, 10:01:16 (UTC)_