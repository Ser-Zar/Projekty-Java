
import java.io.*;
import java.net.*;
import java.util.*;

public class EchoClient {
    public static void main(String[] args) {
        int port = -1;
        if (args.length >= 1) {
            try { port = Integer.parseInt(args[0]); } catch (NumberFormatException ignored) {}
        }
        try (BufferedReader console = new BufferedReader(new InputStreamReader(System.in))) {
            if (port < 0) {
                System.out.print("Enter server port: ");
                String p = console.readLine();
                try { port = Integer.parseInt(p.trim()); } catch (Exception e) {
                    System.err.println("Invalid port");
                    return;
                }
            }

            try (Socket socket = new Socket("localhost", port);
                 PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                 BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

                System.out.println("Connected to server. Type expressions or 'exit' to quit.");
                String line;
                while (true) {
                    System.out.print("> ");
                    line = console.readLine();
                    if (line == null) break;
                    out.println(line);
                    String response = in.readLine();
                    if (response == null) {
                        System.out.println("Server closed connection");
                        break;
                    }
                    System.out.println(response);
                    if (line.equalsIgnoreCase("exit") || line.equalsIgnoreCase("bye")) break;
                }
            } catch (IOException e) {
                System.err.println("Connection error: " + e.getMessage());
            }
        } catch (IOException e) {
            System.err.println("Console error: " + e.getMessage());
        }
    }
}
