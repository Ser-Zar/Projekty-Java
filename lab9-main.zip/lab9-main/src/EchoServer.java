
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.regex.*;

public class EchoServer {
    public static void main(String[] args) throws IOException {
        try (ServerSocket serverSocket = new ServerSocket(0)) {
            System.out.println(serverSocket.getLocalPort()); // wypisz port
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected: " + clientSocket.getRemoteSocketAddress());
                new Thread(() -> handleClient(clientSocket)).start();
            }
        }
    }

    private static void handleClient(Socket clientSocket) {
        try (Socket socket = clientSocket;
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {

            String input;
            while ((input = in.readLine()) != null) {
                String trimmed = input.trim();
                if ("exit".equalsIgnoreCase(trimmed)) {
                    out.println("Zakonczono polaczenie.");
                    break;
                }
                out.println(evaluateExpression(input));
            }
        } catch (IOException e) {
            System.err.println("Client handling error: " + e.getMessage());
        } finally {
            System.out.println("Client disconnected: " + clientSocket.getRemoteSocketAddress());
        }
    }

    private static boolean isOperator(String s) {
        return s.length() == 1 && (s.equals("+") || s.equals("-") || s.equals("*") || s.equals("/"));
    }

    private static String evaluateExpression(String expr) {
        if (expr == null) return "Error: null";
        expr = expr.replaceAll("\\s+", "");
        if (expr.isEmpty()) return "Error: empty";

        List<String> tokens = new ArrayList<>();
        int i = 0;
        while (i < expr.length()) {
            char c = expr.charAt(i);
            if (c == '+' || c == '-' || c == '*' || c == '/') {
                // unary minus handling: gdy '-' jest na początku lub po innym operatorze, traktuj jako część liczby
                if (c == '-' && (tokens.isEmpty() || isOperator(tokens.get(tokens.size() - 1)))) {
                    int j = i + 1;
                    if (j < expr.length() && (Character.isDigit(expr.charAt(j)) || expr.charAt(j) == '.')) {
                        StringBuilder num = new StringBuilder("-");
                        while (j < expr.length() && (Character.isDigit(expr.charAt(j)) || expr.charAt(j) == '.')) {
                            num.append(expr.charAt(j++));
                        }
                        tokens.add(num.toString());
                        i = j;
                        continue;
                    } else {
                        return "Error: invalid expression";
                    }
                } else {
                    tokens.add(String.valueOf(c));
                    i++;
                    continue;
                }
            } else if (Character.isDigit(c) || c == '.') {
                int j = i;
                StringBuilder num = new StringBuilder();
                while (j < expr.length() && (Character.isDigit(expr.charAt(j)) || expr.charAt(j) == '.')) {
                    num.append(expr.charAt(j++));
                }
                tokens.add(num.toString());
                i = j;
            } else {
                return "Error: invalid character";
            }
        }

        if (tokens.isEmpty()) return "Error: invalid expression";
        try {
            double acc = Double.parseDouble(tokens.get(0));
            for (int k = 1; k < tokens.size(); k += 2) {
                if (k + 1 >= tokens.size()) return "Error: invalid expression";
                String op = tokens.get(k);
                if (!isOperator(op)) return "Error: invalid operator";
                double val = Double.parseDouble(tokens.get(k + 1));
                switch (op) {
                    case "+" -> acc += val;
                    case "-" -> acc -= val;
                    case "*" -> acc *= val;
                    case "/" -> {
                        if (val == 0.0) return "Error: division by zero";
                        acc /= val;
                    }
                    default -> { return "Error: invalid operator"; }
                }
            }
            if (Math.abs(acc - Math.round(acc)) < 1e-9) return String.valueOf((long) Math.round(acc));
            return String.valueOf(acc);
        } catch (NumberFormatException e) {
            return "Error: number format";
        }
    }
}
