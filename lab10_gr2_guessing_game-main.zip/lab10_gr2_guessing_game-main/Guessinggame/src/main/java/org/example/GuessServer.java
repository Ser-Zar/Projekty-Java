package org.example;
// `GuessServer.java`
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;

public class GuessServer {
    public static final int PORT = 5555;
    private static int multiNumber;
    private static final AtomicBoolean multiActive = new AtomicBoolean(false);
    private static final Random random = new Random();

    public static synchronized void resetMultiplayerGame() {
        multiNumber = random.nextInt(100) + 1;
        multiActive.set(true);
        System.out.println("Nowa gra multiplayer. Liczba wygenerowana.");
    }

    // Zwraca: 0 = trafione, -1 = zgadnięta liczba jest większa (czyli Twoje zgadywanie było za małe),
    // 1 = zgadnięta liczba jest mniejsza (Twoje zgadywanie było za duże)
    // Integer.MIN_VALUE = gra nieaktywna
    public static synchronized int compareMultiGuess(int guess) {
        if (!multiActive.get()) return Integer.MIN_VALUE;
        if (guess == multiNumber) {
            multiActive.set(false);
            return 0;
        }
        return (guess < multiNumber) ? -1 : 1;
    }

    // Zachowaj dla kompatybilności (opcjonalne)
    public static synchronized boolean checkMultiGuess(int guess) {
        return compareMultiGuess(guess) == 0;
    }

    public static void main(String[] args) {
        System.out.println("Start serwera na porcie " + PORT);
        ScoreManager.ensureFileExists();
        resetMultiplayerGame();

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            while (true) {
                Socket client = serverSocket.accept();
                System.out.println("Polaczono: " + client.getInetAddress());
                new Thread(new ClientHandler(client)).start();
            }
        } catch (IOException e) {
            System.err.println("Blad serwera: " + e.getMessage());
        }
    }
}
