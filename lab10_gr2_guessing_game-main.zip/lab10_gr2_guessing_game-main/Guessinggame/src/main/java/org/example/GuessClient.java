package org.example;
// GuessClient.java
import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class GuessClient {
    public static void main(String[] args) {
        String host = "localhost";
        int port = 5555;
        try (Socket socket = new Socket(host, port);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
             Scanner sc = new Scanner(System.in)) {

            // wątek czytający komunikaty z serwera
            Thread reader = new Thread(() -> {
                try {
                    String line;
                    while ((line = in.readLine()) != null) {
                        System.out.println("[SERVER] " + line);
                    }
                } catch (IOException ignored) {}
            });
            reader.setDaemon(true);
            reader.start();

            // wysyłanie z konsoli
            while (sc.hasNextLine()) {
                String input = sc.nextLine();
                out.println(input);
            }
        } catch (IOException e) {
            System.err.println("Blad klienta: " + e.getMessage());
        }
    }
}
