package org.example;
// `ClientHandler.java`
import java.io.*;
import java.net.Socket;
import java.util.Locale;

public class ClientHandler implements Runnable {
    private final Socket socket;
    private BufferedReader in;
    private PrintWriter out;

    public ClientHandler(Socket socket) {
        this.socket = socket;
    }

    private void send(String s) {
        out.println(s);
    }

    @Override
    public void run() {
        try {
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
            send("Witaj w Guessing Game! Wybierz tryb: 1=single, 2=multi");
            String mode = in.readLine();
            if (mode == null) return;

            if (mode.trim().equals("2")) {
                handleMultiplayer();
            } else {
                handleSingleplayer();
            }
        } catch (IOException e) {
            System.err.println("Blad klienta: " + e.getMessage());
        } finally {
            try { socket.close(); } catch (IOException ignored) {}
        }
    }

    private void handleSingleplayer() throws IOException {
        send("Tryb singleplayer. Wybierz poziom trudnosci: 1=Latwy(1-50),2=Sredni(1-100),3=Trudny(1-200)");
        int lower = 1, upper = 100, maxAttempts = Integer.MAX_VALUE;
        try {
            String diff = in.readLine();
            if ("1".equals(diff)) { upper = 50; maxAttempts = Integer.MAX_VALUE; }
            else if ("3".equals(diff)) { upper = 200; maxAttempts = 5; }
            else { upper = 100; maxAttempts = 10; }
        } catch (Exception ignored) {}

        int number = (int)(Math.random() * upper) + 1;
        int attempts = 0;
        int lowerBound = lower, upperBound = upper;
        send(String.format(Locale.ROOT, "Zgadnij liczbe z zakresu %d - %d. Maksymalna ilosc prob: %s", lowerBound, upperBound,
                maxAttempts==Integer.MAX_VALUE?"brak":maxAttempts));

        while (attempts < maxAttempts) {
            send(String.format("Podaj liczbe (%d - %d):", lowerBound, upperBound));
            String line = in.readLine();
            if (line == null) return;
            int guess;
            try { guess = Integer.parseInt(line.trim()); } catch (NumberFormatException e) { send("Nieprawidlowa liczba."); continue; }
            attempts++;

            if (Math.abs(guess - number) <= 5) send("Bardzo blisko!");
            else if (Math.abs(guess - number) >= 20) send("Daleko!");
            else send("Zblizasz sie!");

            if (guess < number) {
                send("Za malo!");
                lowerBound = Math.max(lowerBound, guess + 1);
            } else if (guess > number) {
                send("Za duzo!");
                upperBound = Math.min(upperBound, guess - 1);
            } else {
                send("Gratulacje! Zgadles liczbe.");
                send("Liczba prob: " + attempts);
                send("Podaj swoje imie do rankingu:");
                String name = in.readLine();
                if (name == null) name = "Anonim";
                ScoreManager.saveBestScore(name.trim(), attempts);
                send("Top wyniki:");
                for (String s : ScoreManager.displayBestScores()) send(s);
                return;
            }
        }
        send("Przegrales — wykorzystales mozliwa ilosc prob.");
    }

    private void handleMultiplayer() throws IOException {
        send("Dolaczasz do gry multiplayer (wspolna liczba dla wszystkich). Zgaduj od 1 do 100.");
        int attempts = 0;
        int lowerBound = 1, upperBound = 100;

        synchronized (GuessServer.class) {
            // jeśli gra nieaktywna serwer wygeneruje nową
            if (GuessServer.compareMultiGuess(Integer.MIN_VALUE) == Integer.MIN_VALUE) {
                GuessServer.resetMultiplayerGame();
            }
        }

        while (true) {
            send(String.format("Podaj liczbe (%d - %d):", lowerBound, upperBound));
            String line = in.readLine();
            if (line == null) return;
            int guess;
            try { guess = Integer.parseInt(line.trim()); } catch (NumberFormatException e) { send("Nieprawidłowa liczba."); continue; }
            attempts++;

            int cmp = GuessServer.compareMultiGuess(guess);
            if (cmp == Integer.MIN_VALUE) {
                // gra została zresetowana przez innego gracza w międzyczasie
                send("Gra zostala zresetowana. Generuje nowa liczbe.");
                GuessServer.resetMultiplayerGame();
                lowerBound = 1; upperBound = 100;
                continue;
            }

            if (cmp == 0) {
                // zwycięzca
                broadcastAll(String.format("Gracz %s wygral w multiplayer! Proby: %d", socket.getInetAddress(), attempts));
                send("Gratulacje! Zgadles liczbe.");
                send("Podaj swoje imie do rankingu:");
                String name = in.readLine();
                if (name == null) name = "Anonim";
                ScoreManager.saveBestScore(name.trim(), attempts);
                GuessServer.resetMultiplayerGame();
                return;
            } else {
                // komunikaty wyżej/niżej
                if (cmp < 0) {
                    send("Za malo!");
                    lowerBound = Math.max(lowerBound, guess + 1);
                } else {
                    send("Za duzo!");
                    upperBound = Math.min(upperBound, guess - 1);
                }

                // dodatkowe inteligentne podpowiedzi (serwer zna liczbę, więc używamy compare + różnic)
                // aby uzyskać różnicę, możemy wykonać pomocniczo porównanie odległości przez tymczasową metodę,
                // ale tu uprościmy: ponownie porównujemy z dostępem do serwera (zakładamy, że compareMultiGuess
                // implementacja ma dostęp do liczby; do uzyskania różnicy trzeba by dodać metodę zwracającą dystans,
                // zamiast komplikować — użyjemy heurystyki na podstawie bounds).
                int range = upperBound - lowerBound;
                if (range <= 10) {
                    send("Bardzo blisko!");
                } else if (range >= 50) {
                    send("Daleko!");
                } else {
                    send("Zblizasz się!");
                }

                send(String.format("Twoje proby: %d", attempts));
            }
        }
    }

    private void broadcastAll(String message) {
        // dla uproszczenia: tylko log na serwerze i wysyłka do bieżącego klienta
        System.out.println("[MULTI BROADCAST] " + message);
        send(message);
    }
}
