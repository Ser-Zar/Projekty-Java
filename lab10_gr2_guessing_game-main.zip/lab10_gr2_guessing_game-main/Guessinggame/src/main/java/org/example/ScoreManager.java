package org.example;
// ScoreManager.java
import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

public class ScoreManager {
    private static final File SCORE_FILE = new File("scores.txt");

    public static synchronized void ensureFileExists() {
        try {
            if (!SCORE_FILE.exists()) SCORE_FILE.createNewFile();
        } catch (IOException ignored) {}
    }

    public static synchronized void saveBestScore(String playerName, int attempts) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(SCORE_FILE, true))) {
            writer.println(playerName + ":" + attempts);
        } catch (IOException e) {
            System.err.println("Blad zapisu wyniku: " + e.getMessage());
        }
    }

    public static synchronized List<String> displayBestScores() {
        List<Map.Entry<String,Integer>> list = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(SCORE_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(":");
                if (parts.length != 2) continue;
                try {
                    list.add(new AbstractMap.SimpleEntry<>(parts[0], Integer.parseInt(parts[1])));
                } catch (NumberFormatException ignored) {}
            }
        } catch (IOException ignored) {}

        List<String> out = list.stream()
                .sorted(Comparator.comparingInt(Map.Entry::getValue))
                .limit(5)
                .map(e -> e.getKey() + " - " + e.getValue() + " prob")
                .collect(Collectors.toList());

        if (out.isEmpty()) out.add("Brak zapisanych wynikow.");
        return out;
    }
}
