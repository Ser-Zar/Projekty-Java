public class MicroException extends Exception {
    private final String lineContent;
    private final int lineNumber;

    public MicroException(String lineContent, int lineNumber) {
        super(lineContent);
        this.lineContent = lineContent;
        this.lineNumber = lineNumber;
    }

    public int getLine() {
        return lineNumber;
    }

    @Override
    public String getMessage() {
        return lineContent;
    }
}