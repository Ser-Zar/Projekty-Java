import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MicroDVDDelay {
    private static final Pattern LINE_PATTERN = Pattern.compile("^\\{(\\d+)\\}\\{(\\d+)\\}(.*)$");
    private int currentLine = 0;

    public String delay(String in, int delay, int fps) throws MicroException {
        currentLine++;

        if (in == null) {
            throw new InvalidFormatException("", currentLine);
        }

        Matcher m = LINE_PATTERN.matcher(in);
        if (!m.matches()) {
            throw new InvalidFormatException(in, currentLine);
        }

        String startStr = m.group(1);
        String endStr = m.group(2);
        String text = m.group(3);

        long start;
        long end;
        try {
            start = Long.parseLong(startStr);
            end = Long.parseLong(endStr);
        } catch (NumberFormatException e) {
            throw new InvalidFormatException(in, currentLine);
        }

        long shiftFrames = Math.round(delay * (fps / 1000.0));
        long newStart = start + shiftFrames;
        long newEnd = end + shiftFrames;

        if (newStart < 0 || newEnd < 0 || newStart > newEnd) {
            throw new InvalidFrameSequenceException(in, currentLine);
        }

        return "{" + newStart + "}{" + newEnd + "}" + text;
    }
}
