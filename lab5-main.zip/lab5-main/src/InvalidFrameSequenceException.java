public class InvalidFrameSequenceException extends MicroException {
    public InvalidFrameSequenceException(String lineContent, int errorLine) {
        super(lineContent, errorLine);
    }
}