public class InvalidFormatException extends MicroException {
    public InvalidFormatException(String lineContent, int errorLine) {
        super(lineContent, errorLine);
    }
}