import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Main {

    public static void main(String[] args) {
        // Expected: inputFile outputFile delayMs fps
        if (args.length != 4) {
            System.err.println("Usage: java Main <input_file> <output_file> <delay_ms> <fps>");
            return;
        }

        String inputFile = args[0];
        String outputFile = args[1];

        int delayMs;
        int fps;

        try {
            delayMs = Integer.parseInt(args[2]);
            fps = Integer.parseInt(args[3]);
        } catch (NumberFormatException e) {
            System.err.println("Delay and fps must be integers");
            return;
        }

        MicroDVDDelay microDVDDelay = new MicroDVDDelay();

        try (BufferedReader br = new BufferedReader(new FileReader(inputFile));
             PrintWriter pw = new PrintWriter(new FileWriter(outputFile))) {

            String line;
            while ((line = br.readLine()) != null) {
                try {
                    String delayed = microDVDDelay.delay(line, delayMs, fps);
                    pw.println(delayed);
                } catch (MicroException me) {
                    // Print erroneous line number to stdout
                    System.out.println(me.getLine());
                    // On error, output file should not contain partial result
                    pw.flush();
                    // Truncate the file by reopening it empty
                    try (PrintWriter clear = new PrintWriter(new FileWriter(outputFile))) {
                        // write nothing, just truncate
                    } catch (IOException ignored) {
                    }
                    return;
                }
            }
        } catch (IOException e) {
            // For this assignment, typically you do not print anything on IO error
            // or you can print to stderr if needed.
        }
    }
}
