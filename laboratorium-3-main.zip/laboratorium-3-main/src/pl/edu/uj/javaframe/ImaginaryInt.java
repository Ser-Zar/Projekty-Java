package pl.edu.uj.javaframe;

public class ImaginaryInt extends Int {
    int imag; // package-private so other package classes can access if needed

    @Override
    public Value create(String val) {
        ImaginaryInt v = new ImaginaryInt();
        if (val.contains("i")) {
            String[] parts = val.split("i", 2);
            v.value = Integer.parseInt(parts[0]);
            v.imag = Integer.parseInt(parts[1]);
        } else {
            v.value = Integer.parseInt(val);
            v.imag = 0;
        }
        return v;
    }

    @Override
    public Value add(Value other) {
        ImaginaryInt result = new ImaginaryInt();

        int thisReal = (Integer) this.value;
        int thisImag = this.imag;

        int otherReal = 0;
        int otherImag = 0;

        if (other instanceof ImaginaryInt) {
            ImaginaryInt o = (ImaginaryInt) other;
            otherReal = (Integer) o.value;
            otherImag = o.imag;
        } else if (other instanceof ImaginaryDouble) {
            ImaginaryDouble o = (ImaginaryDouble) other;
            otherReal = Double.valueOf(o.value.toString()).intValue();
            otherImag = Double.valueOf(o.imag).intValue();
        } else {
            // Int or MyDouble or other Value
            if (other.value instanceof Integer) {
                otherReal = (Integer) other.value;
            } else {
                otherReal = Double.valueOf(other.value.toString()).intValue();
            }
            otherImag = 0;
        }

        result.value = thisReal + otherReal;
        result.imag = thisImag + otherImag;
        return result;
    }

    @Override
    public Value sub(Value other) {
        ImaginaryInt result = new ImaginaryInt();

        int a = (Integer) this.value;
        int b = this.imag;

        int c = 0;
        int d = 0;

        if (other instanceof ImaginaryInt) {
            ImaginaryInt o = (ImaginaryInt) other;
            c = (Integer) o.value;
            d = o.imag;
        } else if (other instanceof ImaginaryDouble) {
            ImaginaryDouble o = (ImaginaryDouble) other;
            c = Double.valueOf(o.value.toString()).intValue();
            d = Double.valueOf(o.imag).intValue();
        } else {
            if (other.value instanceof Integer) {
                c = (Integer) other.value;
            } else {
                c = Double.valueOf(other.value.toString()).intValue();
            }
            d = 0;
        }

        result.value = a - c;
        result.imag = b - d;
        return result;
    }

    @Override
    public Value mul(Value other) {
        ImaginaryInt result = new ImaginaryInt();

        int a = (Integer) this.value;
        int b = this.imag;

        int c = 0;
        int d = 0;

        if (other instanceof ImaginaryInt) {
            ImaginaryInt o = (ImaginaryInt) other;
            c = (Integer) o.value;
            d = o.imag;
        } else if (other instanceof ImaginaryDouble) {
            ImaginaryDouble o = (ImaginaryDouble) other;
            c = Double.valueOf(o.value.toString()).intValue();
            d = Double.valueOf(o.imag).intValue();
        } else {
            if (other.value instanceof Integer) {
                c = (Integer) other.value;
            } else {
                c = Double.valueOf(other.value.toString()).intValue();
            }
            d = 0;
        }

        result.value = a * c - b * d;
        result.imag = a * d + b * c;
        return result;
    }

    @Override
    public Value div(Value other) {
        ImaginaryInt result = new ImaginaryInt();

        int a = (Integer) this.value;
        int b = this.imag;

        double c = 0.0;
        double d = 0.0;

        if (other instanceof ImaginaryInt) {
            ImaginaryInt o = (ImaginaryInt) other;
            c = (Integer) o.value;
            d = o.imag;
        } else if (other instanceof ImaginaryDouble) {
            ImaginaryDouble o = (ImaginaryDouble) other;
            c = (Double) o.value;
            d = o.imag;
        } else {
            if (other.value instanceof Integer) {
                c = (Integer) other.value;
            } else {
                c = Double.valueOf(other.value.toString());
            }
            d = 0.0;
        }

        double denom = c * c + d * d;
        if (denom == 0.0) {
            result.value = 0;
            result.imag = 0;
        } else {
            double realNum = a * c + b * d;
            double imagNum = b * c - a * d;
            result.value = (int) (realNum / denom);
            result.imag = (int) (imagNum / denom);
        }
        return result;
    }

    @Override
    public Value pow(Value other) {
        // Prefer integer exponents; if exponent has imaginary part non-zero -> return zeroed result
        int a = (Integer) this.value;
        int b = this.imag;

        double exponentReal = 0.0;
        double exponentImag = 0.0;

        if (other instanceof ImaginaryInt) {
            ImaginaryInt o = (ImaginaryInt) other;
            exponentReal = (Integer) o.value;
            exponentImag = o.imag;
        } else if (other instanceof ImaginaryDouble) {
            ImaginaryDouble o = (ImaginaryDouble) other;
            exponentReal = (Double) o.value;
            exponentImag = o.imag;
        } else {
            if (other.value instanceof Integer) {
                exponentReal = (Integer) other.value;
            } else {
                exponentReal = Double.valueOf(other.value.toString());
            }
            exponentImag = 0.0;
        }

        if (exponentImag != 0.0) {
            ImaginaryInt res = new ImaginaryInt();
            res.value = 0;
            res.imag = 0;
            return res;
        }

        // If exponent is an integer, do repeated multiplication in integer domain
        double exp = exponentReal;
        ImaginaryInt res = new ImaginaryInt();
        if (Double.isNaN(exp)) {
            res.value = 0;
            res.imag = 0;
            return res;
        }

        // Use double computations then cast to int
        double r = Math.hypot(a, b);
        double theta = Math.atan2(b, a);
        double rPow = Math.pow(r, exp);
        double realPart = rPow * Math.cos(exp * theta);
        double imagPart = rPow * Math.sin(exp * theta);

        res.value = (int) realPart;
        res.imag = (int) imagPart;
        return res;
    }

    @Override
    public boolean eq(Value v) {
        int thisReal = (Integer) this.value;
        int thisImag = this.imag;

        int oReal = 0;
        int oImag = 0;

        if (v instanceof ImaginaryInt) {
            ImaginaryInt o = (ImaginaryInt) v;
            oReal = (Integer) o.value;
            oImag = o.imag;
        } else if (v instanceof ImaginaryDouble) {
            ImaginaryDouble o = (ImaginaryDouble) v;
            oReal = Double.valueOf(o.value.toString()).intValue();
            oImag = Double.valueOf(o.imag).intValue();
        } else {
            if (v.value instanceof Integer) {
                oReal = (Integer) v.value;
            } else {
                oReal = Double.valueOf(v.value.toString()).intValue();
            }
            oImag = 0;
        }

        return thisReal == oReal && thisImag == oImag;
    }

    @Override
    public boolean lte(Value v) {
        // not defined for complex numbers
        return false;
    }

    @Override
    public boolean gte(Value v) {
        // not defined for complex numbers
        return false;
    }

    @Override
    public boolean neq(Value v) {
        return !eq(v);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) return true;
        if (!(other instanceof ImaginaryInt)) return false;
        ImaginaryInt o = (ImaginaryInt) other;
        return (Integer) this.value == (Integer) o.value && this.imag == o.imag;
    }

    @Override
    public int hashCode() {
        int h1 = ((Integer) this.value).hashCode();
        int h2 = Integer.hashCode(this.imag);
        return h1 * 31 + h2;
    }

    @Override
    public String toString() {
        return ((Integer) value).toString() + "i" + Integer.toString(imag);
    }
}
