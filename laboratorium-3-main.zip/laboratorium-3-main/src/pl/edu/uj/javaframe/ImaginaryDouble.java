package pl.edu.uj.javaframe;

public class ImaginaryDouble extends MyDouble {
    double imag; // package-private

    @Override
    public Value create(String val) {
        ImaginaryDouble v = new ImaginaryDouble();
        if (val.contains("i")) {
            String[] parts = val.split("i", 2);
            v.value = Double.parseDouble(parts[0]);
            v.imag = Double.parseDouble(parts[1]);
        } else {
            v.value = Double.parseDouble(val);
            v.imag = 0.0;
        }
        return v;
    }

    @Override
    public Value add(Value other) {
        ImaginaryDouble result = new ImaginaryDouble();

        double thisReal = (Double) this.value;
        double thisImag = this.imag;

        double otherReal = 0.0;
        double otherImag = 0.0;

        if (other instanceof ImaginaryDouble) {
            ImaginaryDouble o = (ImaginaryDouble) other;
            otherReal = (Double) o.value;
            otherImag = o.imag;
        } else if (other instanceof ImaginaryInt) {
            ImaginaryInt o = (ImaginaryInt) other;
            otherReal = Double.valueOf(o.value.toString());
            otherImag = Double.valueOf(o.imag);
        } else {
            // Int or MyDouble or other Value
            if (other.value instanceof Double) {
                otherReal = (Double) other.value;
            } else {
                otherReal = Double.valueOf(other.value.toString());
            }
            otherImag = 0.0;
        }

        result.value = thisReal + otherReal;
        result.imag = thisImag + otherImag;
        return result;
    }

    @Override
    public Value sub(Value other) {
        ImaginaryDouble result = new ImaginaryDouble();

        double thisReal = (Double) this.value;
        double thisImag = this.imag;

        double oReal = 0.0;
        double oImag = 0.0;

        if (other instanceof ImaginaryDouble) {
            ImaginaryDouble o = (ImaginaryDouble) other;
            oReal = (Double) o.value;
            oImag = o.imag;
        } else if (other instanceof ImaginaryInt) {
            ImaginaryInt o = (ImaginaryInt) other;
            oReal = Double.valueOf(o.value.toString());
            oImag = Double.valueOf(o.imag);
        } else {
            if (other.value instanceof Double) {
                oReal = (Double) other.value;
            } else {
                oReal = Double.valueOf(other.value.toString());
            }
            oImag = 0.0;
        }

        result.value = thisReal - oReal;
        result.imag = thisImag - oImag;
        return result;
    }

    @Override
    public Value mul(Value other) {
        ImaginaryDouble result = new ImaginaryDouble();

        double a = (Double) this.value;
        double b = this.imag;

        double c = 0.0;
        double d = 0.0;

        if (other instanceof ImaginaryDouble) {
            ImaginaryDouble o = (ImaginaryDouble) other;
            c = (Double) o.value;
            d = o.imag;
        } else if (other instanceof ImaginaryInt) {
            ImaginaryInt o = (ImaginaryInt) other;
            c = Double.valueOf(o.value.toString());
            d = Double.valueOf(o.imag);
        } else {
            if (other.value instanceof Double) {
                c = (Double) other.value;
            } else {
                c = Double.valueOf(other.value.toString());
            }
            d = 0.0;
        }

        result.value = a * c - b * d;
        result.imag = a * d + b * c;
        return result;
    }

    @Override
    public Value div(Value other) {
        ImaginaryDouble result = new ImaginaryDouble();

        double a = (Double) this.value;
        double b = this.imag;

        double c = 0.0;
        double d = 0.0;

        if (other instanceof ImaginaryDouble) {
            ImaginaryDouble o = (ImaginaryDouble) other;
            c = (Double) o.value;
            d = o.imag;
        } else if (other instanceof ImaginaryInt) {
            ImaginaryInt o = (ImaginaryInt) other;
            c = Double.valueOf(o.value.toString());
            d = Double.valueOf(o.imag);
        } else {
            if (other.value instanceof Double) {
                c = (Double) other.value;
            } else {
                c = Double.valueOf(other.value.toString());
            }
            d = 0.0;
        }

        double denom = c * c + d * d;
        if (denom == 0.0) {
            // Division by zero -> produce NaN components
            result.value = Double.NaN;
            result.imag = Double.NaN;
        } else {
            double realNum = a * c + b * d;
            double imagNum = b * c - a * d;
            result.value = realNum / denom;
            result.imag = imagNum / denom;
        }
        return result;
    }

    @Override
    public Value pow(Value other) {
        // support real exponents only (other.imag == 0)
        double a = (Double) this.value;
        double b = this.imag;

        double exponentReal = 0.0;
        double exponentImag = 0.0;

        if (other instanceof ImaginaryDouble) {
            ImaginaryDouble o = (ImaginaryDouble) other;
            exponentReal = (Double) o.value;
            exponentImag = o.imag;
        } else if (other instanceof ImaginaryInt) {
            ImaginaryInt o = (ImaginaryInt) other;
            exponentReal = Double.valueOf(o.value.toString());
            exponentImag = Double.valueOf(o.imag);
        } else {
            if (other.value instanceof Double) {
                exponentReal = (Double) other.value;
            } else {
                exponentReal = Double.valueOf(other.value.toString());
            }
            exponentImag = 0.0;
        }

        if (exponentImag != 0.0) {
            // complex exponent not implemented -> return NaN complex
            ImaginaryDouble res = new ImaginaryDouble();
            res.value = Double.NaN;
            res.imag = Double.NaN;
            return res;
        }

        double r = Math.hypot(a, b);
        double theta = Math.atan2(b, a);
        double rPow = Math.pow(r, exponentReal);
        double realPart = rPow * Math.cos(exponentReal * theta);
        double imagPart = rPow * Math.sin(exponentReal * theta);

        ImaginaryDouble res = new ImaginaryDouble();
        res.value = realPart;
        res.imag = imagPart;
        return res;
    }

    @Override
    public boolean eq(Value v) {
        double thisReal = (Double) this.value;
        double thisImag = this.imag;

        double oReal = 0.0;
        double oImag = 0.0;

        if (v instanceof ImaginaryDouble) {
            ImaginaryDouble o = (ImaginaryDouble) v;
            oReal = (Double) o.value;
            oImag = o.imag;
        } else if (v instanceof ImaginaryInt) {
            ImaginaryInt o = (ImaginaryInt) v;
            oReal = Double.valueOf(o.value.toString());
            oImag = Double.valueOf(o.imag);
        } else {
            if (v.value instanceof Double) {
                oReal = (Double) v.value;
            } else {
                oReal = Double.valueOf(v.value.toString());
            }
            oImag = 0.0;
        }

        return Double.compare(thisReal, oReal) == 0 && Double.compare(thisImag, oImag) == 0;
    }

    @Override
    public boolean lte(Value v) {
        // not defined for complex numbers
        return false;
    }

    @Override
    public boolean gte(Value v) {
        // not defined for complex numbers
        return false;
    }

    @Override
    public boolean neq(Value v) {
        return !eq(v);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) return true;
        if (!(other instanceof ImaginaryDouble)) return false;
        ImaginaryDouble o = (ImaginaryDouble) other;
        return Double.compare((Double) this.value, (Double) o.value) == 0
                && Double.compare(this.imag, o.imag) == 0;
    }

    @Override
    public int hashCode() {
        long h1 = Double.doubleToLongBits((Double) this.value);
        long h2 = Double.doubleToLongBits(this.imag);
        return (int) (h1 ^ (h1 >>> 32)) * 31 + (int) (h2 ^ (h2 >>> 32));
    }

    @Override
    public String toString() {
        return ((Double) value).toString() + "i" + Double.toString(imag);
    }
}
