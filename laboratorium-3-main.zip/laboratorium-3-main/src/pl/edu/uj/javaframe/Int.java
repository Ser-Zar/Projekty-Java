package pl.edu.uj.javaframe;

public class Int extends Value {
    @Override
    public Value create(String val) {
        Int v = new Int();
        v.value = Integer.parseInt(val);
        return v;
    }

    @Override
    public Value add(Value v) {
        Int result = new Int();
        if (v.value instanceof Integer) {
            result.value = (Integer) this.value + (Integer) v.value;
        } else {
            result.value = (Integer) this.value + Double.valueOf(v.value.toString()).intValue();
        }
        return result;
    }

    @Override
    public Value sub(Value v) {
        Int result = new Int();
        int a = (Integer) this.value;
        int b = (v.value instanceof Integer) ? (Integer) v.value : Double.valueOf(v.value.toString()).intValue();
        result.value = a - b;
        return result;
    }

    @Override
    public Value mul(Value v) {
        Int result = new Int();
        int a = (Integer) this.value;
        int b = (v.value instanceof Integer) ? (Integer) v.value : Double.valueOf(v.value.toString()).intValue();
        result.value = a * b;
        return result;
    }

    @Override
    public Value div(Value v) {
        Int result = new Int();
        int a = (Integer) this.value;
        double denom = (v.value instanceof Integer) ? (Integer) v.value : Double.valueOf(v.value.toString());
        if (denom == 0.0) {
            result.value = 0;
        } else {
            result.value = (int) (a / denom);
        }
        return result;
    }

    @Override
    public Value pow(Value v) {
        Int result = new Int();
        double base = (Integer) this.value;
        double exp = (v.value instanceof Integer) ? (Integer) v.value : Double.valueOf(v.value.toString());
        double res = Math.pow(base, exp);
        result.value = (int) res;
        return result;
    }

    @Override
    public boolean eq(Value v) {
        int a = (Integer) this.value;
        int b;
        if (v.value instanceof Integer) {
            b = (Integer) v.value;
        } else {
            b = Double.valueOf(v.value.toString()).intValue();
        }
        return a == b;
    }

    @Override
    public boolean lte(Value v) {
        int a = (Integer) this.value;
        int b = (v.value instanceof Integer) ? (Integer) v.value : Double.valueOf(v.value.toString()).intValue();
        return a <= b;
    }

    @Override
    public boolean gte(Value v) {
        int a = (Integer) this.value;
        int b = (v.value instanceof Integer) ? (Integer) v.value : Double.valueOf(v.value.toString()).intValue();
        return a >= b;
    }

    @Override
    public boolean neq(Value v) {
        return !eq(v);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) return true;
        if (!(other instanceof Int)) return false;
        Int o = (Int) other;
        return ((Integer) this.value).equals((Integer) o.value);
    }

    @Override
    public int hashCode() {
        return ((Integer) this.value).hashCode();
    }
}
