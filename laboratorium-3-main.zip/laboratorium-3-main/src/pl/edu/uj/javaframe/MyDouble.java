package pl.edu.uj.javaframe;

public class MyDouble extends Value {
    @Override
    public Value create(String val) {
        MyDouble v = new MyDouble();
        v.value = Double.parseDouble(val);
        return v;
    }

    @Override
    public Value add(Value v) {
        MyDouble result  = new MyDouble();
        double a = (Double) this.value;
        double b = valueToDouble(v);
        result.value = a + b;
        return result;
    }

    @Override
    public Value sub(Value v) {
        MyDouble result = new MyDouble();
        double a = (Double) this.value;
        double b = valueToDouble(v);
        result.value = a - b;
        return result;
    }

    @Override
    public Value mul(Value v) {
        MyDouble result = new MyDouble();
        double a = (Double) this.value;
        double b = valueToDouble(v);
        result.value = a * b;
        return result;
    }

    @Override
    public Value div(Value v) {
        MyDouble result = new MyDouble();
        double a = (Double) this.value;
        double b = valueToDouble(v);
        if (b == 0.0) {
            result.value = Double.NaN;
        } else {
            result.value = a / b;
        }
        return result;
    }

    @Override
    public Value pow(Value v) {
        MyDouble result = new MyDouble();
        double a = (Double) this.value;
        double b = valueToDouble(v);
        result.value = Math.pow(a, b);
        return result;
    }

    @Override
    public boolean eq(Value v) {
        double a = (Double) this.value;
        double b = valueToDouble(v);
        return Double.compare(a, b) == 0;
    }

    @Override
    public boolean lte(Value v) {
        double a = (Double) this.value;
        double b = valueToDouble(v);
        return a <= b;
    }

    @Override
    public boolean gte(Value v) {
        double a = (Double) this.value;
        double b = valueToDouble(v);
        return a >= b;
    }

    @Override
    public boolean neq(Value v) {
        return !eq(v);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) return true;
        if (!(other instanceof MyDouble)) return false;
        MyDouble o = (MyDouble) other;
        return Double.compare((Double) this.value, (Double) o.value) == 0;
    }

    @Override
    public int hashCode() {
        long bits = Double.doubleToLongBits((Double) this.value);
        return (int) (bits ^ (bits >>> 32));
    }

    private double valueToDouble(Value v) {
        if (v == null || v.value == null) return 0.0;
        if (v.value instanceof Double) return (Double) v.value;
        if (v.value instanceof Integer) return ((Integer) v.value).doubleValue();
        try {
            return Double.valueOf(v.value.toString());
        } catch (NumberFormatException e) {
            return Double.NaN;
        }
    }
}
