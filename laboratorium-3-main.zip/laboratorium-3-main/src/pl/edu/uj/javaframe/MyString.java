package pl.edu.uj.javaframe;

public class MyString extends Value {
    @Override
    public Value create(String val) {
        MyString v = new MyString();
        v.value = val;
        return v;
    }

    @Override
    public Value add(Value v) {
        MyString result = new MyString();
        String a = this.value == null ? "null" : this.value.toString();
        String b = v == null || v.value == null ? "null" : v.value.toString();
        result.value = a + b;
        return result;
    }

    @Override
    public Value sub(Value v) {
        throw new UnsupportedOperationException("sub not supported for MyString");
    }

    @Override
    public Value mul(Value v) {
        throw new UnsupportedOperationException("mul not supported for MyString");
    }

    @Override
    public Value div(Value v) {
        throw new UnsupportedOperationException("div not supported for MyString");
    }

    @Override
    public Value pow(Value v) {
        throw new UnsupportedOperationException("pow not supported for MyString");
    }

    @Override
    public boolean eq(Value v) {
        String a = this.value == null ? null : this.value.toString();
        String b = v == null || v.value == null ? null : v.value.toString();
        if (a == null) return b == null;
        return a.equals(b);
    }

    @Override
    public boolean lte(Value v) {
        String a = this.value == null ? "" : this.value.toString();
        String b = v == null || v.value == null ? "" : v.value.toString();
        return a.compareTo(b) <= 0;
    }

    @Override
    public boolean gte(Value v) {
        String a = this.value == null ? "" : this.value.toString();
        String b = v == null || v.value == null ? "" : v.value.toString();
        return a.compareTo(b) >= 0;
    }

    @Override
    public boolean neq(Value v) {
        return !eq(v);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) return true;
        if (!(other instanceof MyString)) return false;
        MyString o = (MyString) other;
        String a = this.value == null ? null : this.value.toString();
        String b = o.value == null ? null : o.value.toString();
        if (a == null) return b == null;
        return a.equals(b);
    }

    @Override
    public int hashCode() {
        return (value == null) ? 0 : value.toString().hashCode();
    }
}
