Dear Student,

I'm happy to announce that you've managed to get **5.0** out of 5.0 points for this assignment.
A travelling bard has written a song to commemorate your brave deeds:
        
> Now you're a Hero. \
> You managed to beat the lab today. \
> I'm happy you made it. \
> But how are you going to spend the rest of this day? \
> Maybe watch a video... \
> Maybe press [this link and play a game](https://www.crazygames.com/game/you-have-to-burn-the-rope).


-----------
I remain your faithful servant\
_Bobot_\
_November 05, AD 2025, 08:55:20 (UTC)_