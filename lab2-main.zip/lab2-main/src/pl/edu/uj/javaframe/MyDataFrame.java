package pl.edu.uj.javaframe;

public class MyDataFrame extends DataFrame{
    public MyDataFrame(Class<? extends Value>[] types, String[] vals) {
        super(types, vals);
    }

    public void print() {
        // print header
        for (int i = 0; i < columns.size(); i++) {
            System.out.print(columns.get(i).name);
            if (i < columns.size() - 1) System.out.print('\t');
        }
        System.out.println();
        // print all rows
        if (columns.isEmpty()) return;
        int rows = columns.get(0).values.size();
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < columns.size(); c++) {
                System.out.print(columns.get(c).values.get(r).toString());
                if (c < columns.size() - 1) System.out.print('\t');
            }
            System.out.println();
        }
    }
}