package pl.edu.uj.javaframe;

public class ImaginaryDouble extends MyDouble {
    double imag; // package-private

    @Override
    public Value create(String val) {
        ImaginaryDouble v = new ImaginaryDouble();
        if (val.contains("i")) {
            String[] parts = val.split("i", 2);
            v.value = Double.parseDouble(parts[0]);
            v.imag = Double.parseDouble(parts[1]);
        } else {
            v.value = Double.parseDouble(val);
            v.imag = 0.0;
        }
        return v;
    }

    @Override
    public Value add(Value other) {
        ImaginaryDouble result = new ImaginaryDouble();

        double thisReal = (Double) this.value;
        double thisImag = this.imag;

        double otherReal = 0.0;
        double otherImag = 0.0;

        if (other instanceof ImaginaryDouble) {
            ImaginaryDouble o = (ImaginaryDouble) other;
            otherReal = (Double) o.value;
            otherImag = o.imag;
        } else if (other instanceof ImaginaryInt) {
            ImaginaryInt o = (ImaginaryInt) other;
            otherReal = Double.valueOf(o.value.toString());
            otherImag = Double.valueOf(o.imag);
        } else {
            // Int or MyDouble or other Value
            if (other.value instanceof Double) {
                otherReal = (Double) other.value;
            } else {
                otherReal = Double.valueOf(other.value.toString());
            }
            otherImag = 0.0;
        }

        result.value = thisReal + otherReal;
        result.imag = thisImag + otherImag;
        return result;
    }

    @Override
    public String toString() {
        return ((Double) value).toString() + "i" + Double.toString(imag);
    }
}