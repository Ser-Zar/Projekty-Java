package pl.edu.uj.javaframe;

public class ImaginaryInt extends Int {
    int imag; // package-private so other package classes can access if needed

    @Override
    public Value create(String val) {
        ImaginaryInt v = new ImaginaryInt();
        if (val.contains("i")) {
            String[] parts = val.split("i", 2);
            v.value = Integer.parseInt(parts[0]);
            v.imag = Integer.parseInt(parts[1]);
        } else {
            v.value = Integer.parseInt(val);
            v.imag = 0;
        }
        return v;
    }

    @Override
    public Value add(Value other) {
        ImaginaryInt result = new ImaginaryInt();

        int thisReal = (Integer) this.value;
        int thisImag = this.imag;

        int otherReal = 0;
        int otherImag = 0;

        if (other instanceof ImaginaryInt) {
            ImaginaryInt o = (ImaginaryInt) other;
            otherReal = (Integer) o.value;
            otherImag = o.imag;
        } else if (other instanceof ImaginaryDouble) {
            ImaginaryDouble o = (ImaginaryDouble) other;
            otherReal = Double.valueOf(o.value.toString()).intValue();
            otherImag = Double.valueOf(o.imag).intValue();
        } else {
            // Int or MyDouble or other Value
            if (other.value instanceof Integer) {
                otherReal = (Integer) other.value;
            } else {
                otherReal = Double.valueOf(other.value.toString()).intValue();
            }
            otherImag = 0;
        }

        result.value = thisReal + otherReal;
        result.imag = thisImag + otherImag;
        return result;
    }

    @Override
    public String toString() {
        return ((Integer) value).toString() + "i" + Integer.toString(imag);
    }
}