package pl.edu.uj.javaframe;

public abstract class Value{
    protected Object value;
    public abstract Value create(String v);
    public abstract  Value add(Value v);

    /**** YOUR CODE HERE *****/ // Udało się rozwiązać zadanie bez potrzeby implementacji tutaj ewentualnego kodu

    @Override
    public String toString() {
        return value.toString();
    }

    public void print(){System.out.print(toString());}
}