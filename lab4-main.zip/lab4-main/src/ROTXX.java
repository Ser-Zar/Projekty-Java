public class ROTXX implements Algorithm {
    private final String alphabet;
    private final int rotation;

    public ROTXX(String alphabet, int rotation) {
        if (alphabet == null || alphabet.isEmpty()) {
            this.alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        } else {
            this.alphabet = alphabet;
        }
        this.rotation = rotation;
    }

    public ROTXX() {
        this("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", 11);
    }

    @Override
    public String crypt(String inputWord) {
        if (inputWord == null) return null;
        StringBuilder sb = new StringBuilder();
        int n = alphabet.length();
        for (char ch : inputWord.toCharArray()) {
            int idx = alphabet.indexOf(ch);
            if (idx >= 0) {
                int r = (idx + rotation) % n;
                if (r < 0) r += n;
                sb.append(alphabet.charAt(r));
            } else {
                sb.append(ch);
            }
        }
        return sb.toString();
    }

    @Override
    public String decrypt(String inputWord) {
        if (inputWord == null) return null;
        StringBuilder sb = new StringBuilder();
        int n = alphabet.length();
        for (char ch : inputWord.toCharArray()) {
            int idx = alphabet.indexOf(ch);
            if (idx >= 0) {
                int r = (idx - rotation) % n;
                if (r < 0) r += n;
                sb.append(alphabet.charAt(r));
            } else {
                sb.append(ch);
            }
        }
        return sb.toString();
    }
}
