public class Main {
    public static void main(String[] args) {
        String defaultIn = "C:\\Users\\sergi\\IdeaProjects\\lab4\\tocrypt.txt";
        String defaultOut = "C:\\Users\\sergi\\IdeaProjects\\lab4\\result.txt";
        String defaultAction = "crypt";
        String defaultAlg = "rot";

        String in = args.length > 0 ? args[0] : defaultIn;
        String out = args.length > 1 ? args[1] : defaultOut;
        String action = args.length > 2 ? args[2] : defaultAction;
        String algName = args.length > 3 ? args[3] : defaultAlg;

        Algorithm algorithm;
        if ("rot".equalsIgnoreCase(algName)) {
            algorithm = new ROTXX();
        } else if ("pol".equalsIgnoreCase(algName)) {
            algorithm = new Polibiusz();
        } else {
            System.err.println("Unknown algorithm: " + algName);
            return;
        }

        try {
            if ("crypt".equalsIgnoreCase(action)) {
                Cryptographer.cryptfile(in, out, algorithm);
            } else if ("decrypt".equalsIgnoreCase(action)) {
                Cryptographer.decryptfile(in, out, algorithm);
            } else {
                System.err.println("Unknown action: " + action);
            }
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
        /* Szyfrowanie (wejście tocrypt.txt, wyjście result.txt, algorytm rot):
        C:\Users\sergi\IdeaProjects\lab4\tocrypt.txt C:\Users\sergi\IdeaProjects\lab4\result.txt crypt rot
         Deszyfrowanie (wejście result.txt, wyjście decoded.txt, algorytm rot):
         C:\Users\sergi\IdeaProjects\lab4\result.txt C:\Users\sergi\IdeaProjects\lab4\decoded.txt decrypt rot
         */

    }
}
