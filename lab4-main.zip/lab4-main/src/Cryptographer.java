// java
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.charset.StandardCharsets;
import java.io.IOException;

public class Cryptographer {
    public static void cryptfile(String path_to_file_in, String path_to_file_out, Algorithm algorithm) throws IOException {
        String content = new String(Files.readAllBytes(Paths.get(path_to_file_in)), StandardCharsets.UTF_8);
        StringBuilder out = new StringBuilder();
        int i = 0;
        while (i < content.length()) {
            if (Character.isWhitespace(content.charAt(i))) {
                int start = i;
                while (i < content.length() && Character.isWhitespace(content.charAt(i))) i++;

                out.append(content, start, i);
            } else {
                int start = i;
                while (i < content.length() && !Character.isWhitespace(content.charAt(i))) i++;
                String word = content.substring(start, i);
                out.append(algorithm.crypt(word));
            }
        }
        Files.write(Paths.get(path_to_file_out), out.toString().getBytes(StandardCharsets.UTF_8));
    }

    public static void decryptfile(String path_to_file_in, String path_to_file_out, Algorithm algorithm) throws IOException {
        String content = new String(Files.readAllBytes(Paths.get(path_to_file_in)), StandardCharsets.UTF_8);
        StringBuilder out = new StringBuilder();
        int i = 0;
        while (i < content.length()) {
            if (Character.isWhitespace(content.charAt(i))) {
                int start = i;
                while (i < content.length() && Character.isWhitespace(content.charAt(i))) i++;
                out.append(content, start, i);
            } else {

                int start = i;
                while (i < content.length() && !Character.isWhitespace(content.charAt(i))) i++;
                String token = content.substring(start, i);


                while (true) {
                    int wsStart = i;
                    while (i < content.length() && Character.isWhitespace(content.charAt(i))) i++;
                    String ws = content.substring(wsStart, i);
                    if (ws.length() == 1 && i < content.length()) {
                        int nextStart = i;
                        while (i < content.length() && !Character.isWhitespace(content.charAt(i))) i++;
                        String nextToken = content.substring(nextStart, i);
                        if (token.matches("\\d+") && nextToken.matches("\\d+")) {

                            token = token + ws + nextToken;

                        } else {

                            i = wsStart;
                            break;
                        }
                    } else {

                        i = wsStart;
                        break;
                    }
                }

                out.append(algorithm.decrypt(token));
            }
        }
        Files.write(Paths.get(path_to_file_out), out.toString().getBytes(StandardCharsets.UTF_8));
    }
}
