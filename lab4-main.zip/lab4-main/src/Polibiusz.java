public class Polibiusz implements Algorithm {
    private final String alphabet;
    private final int size;
    private final String[][] board;

    public Polibiusz(String alphabet, int size) {
        if (alphabet == null) {
            this.alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        } else {
            this.alphabet = alphabet;
        }
        this.size = Math.max(1, size);
        this.board = new String[this.size][this.size];
        int idx = 0;
        for (int r = 0; r < this.size; r++) {
            for (int c = 0; c < this.size; c++) {
                if (idx < this.alphabet.length()) {
                    board[r][c] = String.valueOf(this.alphabet.charAt(idx++));
                } else {
                    board[r][c] = "";
                }
            }
        }
    }

    public Polibiusz() {
        this("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", 5);
    }

    @Override
    public String crypt(String inputWord) {
        if (inputWord == null) return null;
        StringBuilder sb = new StringBuilder();
        for (char ch : inputWord.toCharArray()) {
            if (Character.isWhitespace(ch)) continue;
            String s = String.valueOf(ch);
            boolean found = false;
            for (int r = 0; r < size && !found; r++) {
                for (int c = 0; c < size; c++) {
                    if (s.equals(board[r][c])) {
                        sb.append(r + 1).append(c + 1).append(' ');
                        found = true;
                        break;
                    }
                }
            }

        }

        if (sb.length() > 0 && sb.charAt(sb.length() - 1) == ' ') sb.setLength(sb.length() - 1);
        return sb.toString();
    }

    @Override
    public String decrypt(String inputWord) {
        if (inputWord == null) return null;

        StringBuilder digits = new StringBuilder();
        for (int i = 0; i < inputWord.length(); i++) {
            char ch = inputWord.charAt(i);
            if (Character.isDigit(ch)) digits.append(ch);
        }
        StringBuilder sb = new StringBuilder();
        String d = digits.toString();
        for (int i = 0; i + 1 < d.length(); i += 2) {
            int row = Character.getNumericValue(d.charAt(i)) - 1;
            int col = Character.getNumericValue(d.charAt(i + 1)) - 1;
            if (row >= 0 && row < size && col >= 0 && col < size) {
                String val = board[row][col];
                if (val != null && !val.isEmpty()) sb.append(val);
            }
        }
        return sb.toString();
    }
}
