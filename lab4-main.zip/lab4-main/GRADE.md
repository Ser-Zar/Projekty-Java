Dear Student,

I'm happy to announce that you've managed to get **4.625** out of 5.0 points for this assignment.
<details><summary>You have already managed to pass 3 tests, so that is encouraging!</summary>&emsp;☑&nbsp;[0.5p]&nbsp;Program&nbsp;compiles<br>&emsp;☑&nbsp;[2p]&nbsp;Testing&nbsp;ROT<br>&emsp;☑&nbsp;[2p]&nbsp;Testing&nbsp;Polibiusz</details>

There still exist some issues that should be addressed before the deadline: **2025-11-19 23:50:00 CET (+0100)**. For further details, please refer to the following list:

<details><summary>[0.25p] Program compilation has failed.</summary></details>
<details><summary>[0.125] Encrypring/decrypting files from program arguments failed via Main program arguments.Resulting files does not match. Testing input.txt output.txt crypt pol. Params: square size=5, alphabet=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789. Expecting in file output.txt 11 22 32 54   35, but got 11 22 32 54 35. Input file contains: A.hG?L`~Xz Oz~x|hf%m+j/</summary>Resulting&nbsp;files&nbsp;does&nbsp;not&nbsp;match.&nbsp;Testing&nbsp;input.txt&nbsp;output.txt&nbsp;decrypt&nbsp;pol.&nbsp;Params:&nbsp;square&nbsp;size=5,&nbsp;alphabet=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.&nbsp;Expecting&nbsp;in&nbsp;file&nbsp;output.txt&nbsp;AGLX&nbsp;O,&nbsp;but&nbsp;got&nbsp;AG&nbsp;LX&nbsp;&nbsp;&nbsp;O.&nbsp;Input&nbsp;file&nbsp;contains:&nbsp;11&nbsp;22&nbsp;32&nbsp;54&nbsp;&nbsp;&nbsp;35</details>

-----------
I remain your faithful servant\
_Bobot_\
_November 10, AD 2025, 11:39:37 (UTC)_